// SPDX-License-Identifier: MIT
// OpenZeppelin Contracts (last updated v5.4.0) (interfaces/ITRC721.sol)

pragma solidity >=0.6.2;

import {ITRC721} from "../token/TRC721/ITRC721.sol";
